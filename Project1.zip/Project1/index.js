// console.log("Helloo");
// console.log("Pankaja");
// console.log("Pankaja sharma..");
// console.log("Hellooo.!! Pankaja sharma..");
// console.log("Hellooo.!! Pankaja sharma here..");
var mysql = require("mysql");
var connection = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "password",
  database: "cdac",
});

var express = require("express");
var mongoose = require("mongoose");
var db = require("./database/db.js");

var app = express();
// console.log(db);

app.use(express.json());

db();

const Schema = mongoose.Schema;

const usersschema = new Schema({
  name: String,
  age: Number,
  place: String,
});

const userModel = mongoose.model("users", usersschema);

app.get("/users", async (req, res) => {
  try {
    var result = await userModel.find();
    res.send(result);
  } catch (error) {
    res.send(error.message);
  }
});

app.post("/users", async (req, res) => {
  // console.log(req.body);
  try {
    var record = new userModel(req.body);
    var ans = await record.save();
    res.send("record inserted");
  } catch (error) {
    res.send(error.message);
  }
});

app.put("/users", (req, res) => {
  res.send("update data from database");
});

app.delete("/users", (req, res) => {
  res.send("deletes data from database");
});

//mysql database connection
app.get("/userinfo", function (req, res) {
  connection.query("select * from emp", function (err, result) {
    if (err) {
      res.send(err.message);
    } else {
      res.send(result);
    }
  });
});

app.post("/userinfo", (req, res) => {
  console.log(req.body);
  connection.query(
    "insert into emp set ?",
    req.body,
      function (err, result) {
          if (err) {
            res.send(err.message);
          } else {
              res.send("user added");
        }
    }
  );
});

app.listen(3000);
