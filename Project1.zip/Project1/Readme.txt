npm init -y

npm i express

C:\Program Files\MongoDB\Server\4.2\bin
cmd:mongod.exe
cmd:mongo.exe

use userdetails
show dbs

db.createCollection('users')
show collections

1) insert()
2) insertOne()
3) insertMany()

1) update()
2) updateOne()
3) updateMany()

db.users.insert([{'name':'Pankaja','age': 24,'place':'Nanded'},{'name':'Kajal','age': 24,'place':'Dhule'},{'name':'Nikita','age': 23,'place':'Pune'},{'name':'Siddhi','age': 23,'place':'Shahda'}])
db.users.insert({'name':'Siddhi','age': 23,'place':'Shahda'})

db.users.find().pretty()

db.users.find({place:'Nanded'})

db.users.remove({place:'Shahda'})

db.users.update({place:"Nanded"},{$set:{name:"Pankaja Sharma"}})

npm i mongoose

await mongoose.connect('mongodb://127.0.0.1/my_database');
27017:port for monogodb
module.exports = dbconnect;


var db = require("./database/db.js");
db();----------to connect with db

const Schema = mongoose.Schema;

const usersschema = new Schema({
  name: String,
  age: Number,
  place: String,
});

const userModel = mongoose.model("users", usersschema);

//mysql db connection

var mysql      = require('mysql');
var connection = mysql.createConnection({
  host     : 'localhost',
  user     : 'me',
  password : 'secret',
  database : 'my_db'
});


